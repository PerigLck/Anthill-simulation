#include <Timer.h>

float Timer::m_currentTime;
float Timer::m_deltaTime;
